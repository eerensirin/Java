
public class Q4 {

	public static void main(String[] args) {
	int[] array1 = {3,4,5};
	int[] array2 = {5,8,3};
	int[] array3 = {4,5,5};
	
	int result1 = sumArray(array1);
	int result2 = sumArray(array2);
	int result3 = sumArray(array3);
	
	System.out.println(result1);
	System.out.println(result2);
	System.out.println(result3);


	}

	private static int sumArray(int[] arr) {
	int 	sum = arr[1] + arr[2] + arr[3];
		
		
		return sum;
		
	}
}
