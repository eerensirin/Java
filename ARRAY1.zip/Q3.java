
public class Q3 {
	public static void main(String[] args) {

		int[] array1 = { 3, 4, 5, 5, 8, 3 };
		int[] array2 = { 3, 4, 4, 4, 8, 3 };
		int[] array3 = { 2, 9, 5, 8, 7, 8, 2 };
		int[] array4 = { 9, 5, 5, 5, 8, 2 };
		int[] array5 = { 1, 4, 3, 3, 3, 7, 8, 1 };
		int[] array6 = { 6, 4, 3, 3, 3, 7, 8, 4 };

		boolean result1 = TwoArrayCont(array1, array2);
		boolean result2 = TwoArrayCont(array3, array4);
		boolean result3 = TwoArrayCont(array5, array6);
		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result3);

	}

	private static boolean TwoArrayCont(int[] arr1, int[] arr2) {
		return arr1[0] == arr2[0] || arr1[arr1.length - 1] == arr2[arr2.length - 1];
	}
}
