/*public class Q5 {

	public static void main(String[] args) {
		int[] array1 = { 6, 7, 5 };
		int[] array2 = { 7, 8, 2 };
		int[] array3 = { 8, 9, 5 };

		int[] result1 = reversed(array1);
		int[] result2 = reversed(array2);
		int[] result3 = reversed(array3);

		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result3);

	}

	public static int[] reversed(int[] arr) {
		int[] newArray = { arr[3], arr[2], arr[1] };

		return newArray;
	}

}
*/
public class Q5 {

    public static void main(String[] args) {
        int[] array1 = { 6, 7, 5 };
        int[] array2 = { 7, 8, 2 };
        int[] array3 = { 8, 9, 5 };

        int[] result1 = reversed(array1);
        int[] result2 = reversed(array2);
        int[] result3 = reversed(array3);

        printArray(result1);
        printArray(result2);
        printArray(result3);
    }

    public static int[] reversed(int[] arr) {
        int[] newArray = { arr[2], arr[1], arr[0] };

        return newArray;
    }

    public static void printArray(int[] arr) {
        for (int element : arr) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}
