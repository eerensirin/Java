import java.util.Scanner;

public class q14 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the initial investment amount: ");
        double principal = scanner.nextDouble();
        double annualInterestRate = 0.125; // 12.5% annual interest rate
        int numberOfYears = 10;

        double totalInterest = 0.0;

        for (int year = 1; year <= numberOfYears; year++) {
            double interest = principal * annualInterestRate;
            totalInterest += interest;
            principal += interest;

            System.out.println("Year " + year + " - Interest: " + interest + " - Total Interest: " + totalInterest + " - New Capital: " + principal);
        }

        scanner.close();
    }
}
