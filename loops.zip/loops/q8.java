import java.util.Scanner;
public class q8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		int sum = 0;
		boolean controller = true;
		Scanner keyboard = new Scanner(System.in);
		while(controller == true ) {
			System.out.print("Please Enter Your Number : ");
			num = keyboard.nextInt();
			if(num<100) {
				sum+=num;	
			}
			
			if(num == 0) {
				controller = false; 
				System.out.printf("Your Total is : %d",sum); 
			}
		}
		
		
		
		keyboard.close();
	}

}
