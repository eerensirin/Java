import java.util.Scanner;

public class q6 {
public static void main(String[]args) {
	
	boolean controller = true ; 
	int num;
	Scanner keyboard = new Scanner(System.in);
	while(controller== true ) {
		System.out.print("Enter Your Number : ");
		num = keyboard.nextInt();
		if(num<0) {
			controller = false;
		}
	}
	keyboard.close();
}
}
