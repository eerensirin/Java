import java.util.Scanner;

public class q7 {
public static void main(String[]args) {
	
	boolean controller = true ; 
	int num;
	int sum=0;
	Scanner keyboard = new Scanner(System.in);
	while(controller== true ) {
		System.out.print("Enter Your Number : ");
		sum++;
		num = keyboard.nextInt();
	
		if(num<0) {
			controller = false;
			System.out.printf("Your positive num counts : %d",sum);
		}
	
	}
	keyboard.close();
}
}
