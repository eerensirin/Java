import java.util.Scanner;

public class q10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double totalSalary = 0.0;
        double totalVAT = 0.0;

        while (true) {
            System.out.print("Enter a salary (negative number to exit): ");
            double salary = scanner.nextDouble();

            if (salary < 0) {
                break; // Exit the loop when a negative number is entered
            }

            totalSalary += salary;
            double vat = 0.4 * salary; // Calculate VAT (40% of the salary)
            totalVAT += vat;
        }

        scanner.close();

        System.out.println("Total Salary: " + totalSalary);
        System.out.println("Total VAT: " + totalVAT);
    }
}
