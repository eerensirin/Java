import java.util.Scanner;

public class q9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number;
        boolean isValid = false;

        do {
            System.out.print("Enter a number between 1 and 10: ");
            number = scanner.nextInt();

            if (number >= 1 && number <= 10) {
                isValid = true;
            } else {
                System.out.println("Please re-enter a valid number between 1 and 10.");
            }
        } while (!isValid);

        for (int i = 0; i < number; i++) {
            System.out.println("#");
        }

        scanner.close();
    }
}
