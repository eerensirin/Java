import java.util.Scanner;

public class q13 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double balance = 200.0;
        double withdrawAmount;

        while (balance > 0) {
            System.out.print("Enter the amount to withdraw (0 to exit): ");
            withdrawAmount = scanner.nextDouble();

            if (withdrawAmount == 0) {
                break; // Exit the loop when 0 is entered
            }

            if (withdrawAmount <= balance) {
                balance -= withdrawAmount;
                System.out.println("Withdrawn: " + withdrawAmount + " Euro");
                System.out.println("Remaining balance: " + balance + " Euro");
            } else {
                System.out.println("Insufficient balance. Please enter a smaller amount.");
            }
        }

        scanner.close();
        System.out.println("No more money to withdraw. Program terminated.");
    }
}
