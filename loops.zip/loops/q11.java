import java.util.Scanner;

public class q11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int sum = 0;
        int largest = Integer.MIN_VALUE; 
        int smallest = Integer.MAX_VALUE; 

        while (true) {
            System.out.print("Enter an integer (0 to finish): ");
            int number = scanner.nextInt();

            if (number == 0) {
                break;
            }

            sum += number;

            if (number > largest) {
                largest = number;
            }

            if (number < smallest) {
                smallest = number;
            }
        }

        scanner.close();

        System.out.println("Sum: " + sum);
        System.out.println("Largest number: " + largest);
        System.out.println("Smallest number: " + smallest);
    }
}
