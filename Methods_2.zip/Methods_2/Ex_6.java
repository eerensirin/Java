
public class Ex_6 {

}
