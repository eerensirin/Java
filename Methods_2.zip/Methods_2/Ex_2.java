import java.util.Scanner ; 
public class Ex_2 {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter your Celsius value : ");
		int C = keyboard.nextInt();
		toFahrenheit(C);
		
		keyboard.close();

	}
	private static double toFahrenheit(int C) {
		double F = 9.0 / 5.0 * C + 32 ;
		System.out.print(F);
		return F ;
	}

}
