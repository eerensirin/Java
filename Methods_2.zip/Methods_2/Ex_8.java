import java.util.Scanner;

public class ex_5 {
    public static int sumRange(int start, int end) {
        int sum = 0;
        for (int i = start; i <= end; i++) {
            sum += i;
        }
        return sum;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the first number: ");
        int firstNumber = scanner.nextInt();

        int secondNumber;
        do {
            System.out.print("Enter the second number (must be larger than the first): ");
            secondNumber = scanner.nextInt();
            if (secondNumber <= firstNumber) {
                System.out.println("Second number must be larger than the first number. Try again.");
            }
        } while (secondNumber <= firstNumber);

        int result = sumRange(firstNumber, secondNumber);
        System.out.println("Sum of the numbers in the range is: " + result);

        scanner.close();
    }
}