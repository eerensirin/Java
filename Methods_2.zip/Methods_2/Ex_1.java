import java.util.Scanner ; 
public class Ex_1 {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter your Fahrenheit value : ");
		int F = keyboard.nextInt();
		toCelsius(F);
		
		keyboard.close();

	}
	private static double toCelsius(int F) {
		double C = (5.0 / 9.0) * (F - 32 ); 
		System.out.print(C);
		return C ;
	}

}
