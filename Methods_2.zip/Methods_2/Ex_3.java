import java.util.Scanner;

public class Ex_3 {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.print(
				"Which conversion would you like ? \n1.Fahrenheit to Celsius/n2.Celsius to Fahrenheit\n3.Quit program\nEnter your choice : ");
		int choose = keyboard.nextInt();
		switch (choose) {
		case 1:
			System.out.print("Enter a fahrenheit value to convert : ");
			int F = keyboard.nextInt();
			toCelsius(F);
			break;
		case 2:
			System.out.print("Enter a Celsius value to convert : ");
			int C = keyboard.nextInt();
			toFahrenheit(C);
			break;
		case 3:
			break;
		}

		keyboard.close();
	}

	private static double toCelsius(int F) {
		double C = (5.0 / 9.0) * (F - 32);
		System.out.print(C);
		return C;
	}

	private static double toFahrenheit(int C) {
		double F = 9.0 / 5.0 * C + 32;
		System.out.print(F);
		return F;
	}

}
