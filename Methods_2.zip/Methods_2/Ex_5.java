
public class Ex_5 {

}
