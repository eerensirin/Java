import java.util.Scanner;

public class Q4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first integer: ");
        int num1 = scanner.nextInt();

        System.out.print("Enter the second integer: ");
        int num2 = scanner.nextInt();

        System.out.print("Enter the third integer: ");
        int num3 = scanner.nextInt();

        System.out.print("Enter the fourth integer: ");
        int num4 = scanner.nextInt();

        scanner.close();

        int largest = num1;
        int smallest = num1;

        if (num2 > largest) {
            largest = num2;
        } else if (num2 < smallest) {
            smallest = num2;
        }

        if (num3 > largest) {
            largest = num3;
        } else if (num3 < smallest) {
            smallest = num3;
        }

        if (num4 > largest) {
            largest = num4;
        } else if (num4 < smallest) {
            smallest = num4;
        }

        System.out.println("Largest integer: " + largest);
        System.out.println("Smallest integer: " + smallest);
    }
}
