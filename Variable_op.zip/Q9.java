import java.util.Scanner;

public class Q9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter num1: ");
        int num1 = scanner.nextInt();

        System.out.print("Enter num2: ");
        int num2 = scanner.nextInt();

        scanner.close();

        if (num1 >= 67 && num1 <= 73) {
            System.out.println("num1 is in the range 67 to 73 inclusive.");
        }

        if (num2 > 100 && num2 < 999) {
            System.out.println("num2 is in the range 100 to 999 exclusive.");
        }

        if (!(num1 >= 67 && num1 <= 73) && !(num2 > 100 && num2 < 999)) {
            System.out.println("Neither num1 nor num2 is in the correct value range.");
        }
    }
}
