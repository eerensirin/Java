import java.util.Scanner;

public class Q8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your score: ");
        int score = scanner.nextInt();

        scanner.close();

        String grade;

        if (score >= 85) {
            grade = "A";
        } else if (score >= 70) {
            grade = "B";
        } else if (score >= 55) {
            grade = "C";
        } else if (score >= 40) {
            grade = "D";
        } else {
            grade = "F";
        }

        System.out.println("You got a grade " + grade);
    }
}
