import java.util.Scanner ;
public class Q1 {

	public static void main(String[] args) {
		int num1,num2,sum = 0 ;
		int product=0;
		int difference=0;
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter Your Number : \n");
		num1 = keyboard.nextInt();
		System.out.print("Enter Second Your Number : \n");
		num2 = keyboard.nextInt();
		sum = num1 + num2;
		product = num1 * num2;
		difference = num1 - num2;
				
		System.out.printf("Your numbers sum Equals to : %d\n",sum);
		System.out.printf("Your numbers product  Equals to : %d\n",product);
		System.out.printf("Your numbers difference Equals to : %d",difference);
		
		
		keyboard.close();
	}

}
