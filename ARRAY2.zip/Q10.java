public class Q10 {
	public static void main(String[] args) {
		int[] originalArray1 = { 1, 2, 4, 1 };
		int[] resultArray1 = getElementsBeforeFirst4(originalArray1);
		printArray(resultArray1);

		int[] originalArray2 = { 3, 1, 4 };
		int[] resultArray2 = getElementsBeforeFirst4(originalArray2);
		printArray(resultArray2);

		int[] originalArray3 = { 1, 4, 4 };
		int[] resultArray3 = getElementsBeforeFirst4(originalArray3);
		printArray(resultArray3);
	}

	private static int[] getElementsBeforeFirst4(int[] arr) {
        int index = 0;

        // Find the index of the first occurrence of 4
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == 4) {
                index = i;
                break;
            }
        }

        // Create a new array with elements before the first 4
        int[] resultArray = new int[index];
        System.arraycopy(arr, 0, resultArray, 0, index);

        return resultArray;
    }

private static void printArray(int[] arr) {
        System.out.print("{");
}
}