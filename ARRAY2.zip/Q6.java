public class Q6 {

    public static void main(String[] args) {
        int[] array1 = { 1, 2, 2 };
        int[] array2 = { 4, 4, 1 };
        int[] array3 = { 4, 4, 1, 2, 2 };

        boolean result1 = containsTwoTwosOrTwoFours(array1);
        boolean result2 = containsTwoTwosOrTwoFours(array2);
        boolean result3 = containsTwoTwosOrTwoFours(array3);
        System.out.println(result1);
        System.out.println(result2);
        System.out.println(result3);
    }

    private static boolean containsTwoTwosOrTwoFours(int[] arr) {
        boolean containsTwoTwos = false;
        boolean containsTwoFours = false;

        for (int i = 0; i < arr.length - 1; i++) {
            if (arr[i] == 2 && arr[i + 1] == 2) {
                containsTwoTwos = true;
            }
            if (arr[i] == 4 && arr[i + 1] == 4) {
                containsTwoFours = true;
            }
        }

        return (containsTwoTwos || containsTwoFours) && !(containsTwoTwos && containsTwoFours);
    }
}
