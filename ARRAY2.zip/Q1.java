
public class Q1 {

	public static void main(String[] args) {
		int[] array1 = { 2, 3, 2, 2, 4, 2 };
		int[] array2 = { 2, 3, 2, 2, 4, 2, 2 };
		int[] array3 = { 1, 2, 3, 4 };

		boolean result1 = check(array1);
		boolean result2 = check(array2);
		boolean result3 = check(array3);

		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result3);

	}

	public static boolean check(int[] arr) {
		int sum = 0;
		for (int i = 0; i < arr.length-1; i++) {
			if (arr[i] == 2) {
				sum += arr[i];
			}

		}

		return sum == 8;
	}
}
