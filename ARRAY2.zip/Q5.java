
public class Q5 {

	public static void main(String[] args) {
		int[] array1 = { 0, 2, 4 };
		int[] array2 = { 1, 2, 3 };
		int[] array3 = { 1, 2, 4 };

		boolean result1 = oneandthreecheck(array1);
		boolean result2 = oneandthreecheck(array2);
		boolean result3 = oneandthreecheck(array3);
		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result3);

	}

	private static boolean oneandthreecheck(int[] arr) {
		boolean value = false;
		for (int i = 0; i < arr.length - 1; i++) {
			if (arr[i] == 1 || arr[i] == 3) {
				value = false;
			} else {
				value = true;
			}

		}
		return value;
	}

}
