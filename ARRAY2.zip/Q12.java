import java.util.Scanner;

public class Q12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] numbers = new int[5];
        int index = 0;

        System.out.println("Enter five numbers between 10 and 100 (inclusive):");

        while (index < 5) {
            System.out.print("Enter number " + (index + 1) + ": ");
            int inputNumber = scanner.nextInt();

            if (inputNumber >= 10 && inputNumber <= 100) {
                if (!contains(numbers, index, inputNumber)) {
                    numbers[index] = inputNumber;
                    index++;
                } else {
                    System.out.println("Duplicate number. Please enter a different number.");
                }
            } else {
                System.out.println("Number must be between 10 and 100 (inclusive). Please try again.");
            }
        }

        System.out.print("Final list of numbers: {");
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(numbers[i]);
            if (i < numbers.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("}");

        scanner.close();
    }

    static boolean contains(int[] arr, int endIndex, int number) {
        for (int i = 0; i <= endIndex; i++) {
            if (arr[i] == number) {
                return true;
            }
        }
        return false;
    }
}
