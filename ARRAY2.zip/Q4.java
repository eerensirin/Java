
public class Q4 {

	public static void main(String[] args) {
		int[] array1 = { 1, 2, 2 };
		int[] array2 = { 1, 2, 1, 2 };
		int[] array3 = { 2, 1, 2 };

		boolean result1 = twototwo(array1);
		boolean result2 = twototwo(array2);
		boolean result3 = twototwo(array3);
		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result3);

	}

	private static boolean twototwo(int[] arr) {
		boolean value = true;
		for (int i = 0; i < arr.length -1  ; i++) {
			if (arr[i] == 2 && arr[i+1] == 2) {
				value = true;
			} else {
				value = false;
			}

		}
		return value;
	}

}
