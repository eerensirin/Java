
public class Q3 {

	public static void main(String[] args) {
		int[] array1 = { 1, 4, 1, 4 };
		int[] array2 = { 1, 4, 2, 4 };
		int[] array3 = { 1, 1 };

		boolean result1 = fourandonecheck(array1);
		boolean result2 = fourandonecheck(array2);
		boolean result3 = fourandonecheck(array3);
		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result3);

	}

	private static boolean fourandonecheck(int[] arr) {
		boolean value = false;
		for (int i = 0; i < arr.length -1; i++) {
			if (arr[i] == 1 || arr[i] == 4) {
				value = true;
			} else {
				value = false;
			}

		}
		return value;
	}

}
